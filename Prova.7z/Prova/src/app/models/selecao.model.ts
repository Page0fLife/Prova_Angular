export interface Selecao {
  id?: number;
  nome: string;
  criadoEm?: string;
}
