import { Jogo } from './jogo.model';
export interface palpite {
    id?: number;
    jogo?: Jogo;
    palpiteA: Number;
    palpiteB: Number;
    criadoEm?: string;
  }